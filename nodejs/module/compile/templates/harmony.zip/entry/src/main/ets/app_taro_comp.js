import { initPxTransform } from './npm/@tarojs/taro';
import { createReactApp } from './npm/@tarojs/plugin-framework-react/dist/runtime';
import App from './app_comp.js';
import * as React from './npm/react';
import ReactDom from './npm/@tarojs/react';

const config = {
  "entryPagePath": "pages/index/index",
  "pages": ["pages/index/index", "pages/404/index"],
  "networkTimeout": {
    "request": 10000,
    "downloadFile": 10000
  }
};
initPxTransform({
  designWidth: 375,
  deviceRatio: {
    "375": 1
  },
  baseFontSize: undefined,
  unitPrecision: undefined,
  targetUnit: undefined
});
const app = () => createReactApp(App, React, ReactDom, config);

export { config, app as default };
//# sourceMappingURL=app_taro_comp.js.map

// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 我的小程序
export const checkIsAddedToMyMiniProgram = /* @__PURE__ */ temporarilyNotSupport('checkIsAddedToMyMiniProgram')

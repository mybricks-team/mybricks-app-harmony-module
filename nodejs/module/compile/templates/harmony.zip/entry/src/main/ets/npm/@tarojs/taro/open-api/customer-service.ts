// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 微信客服
export const openCustomerServiceChat = /* @__PURE__ */ temporarilyNotSupport('openCustomerServiceChat')

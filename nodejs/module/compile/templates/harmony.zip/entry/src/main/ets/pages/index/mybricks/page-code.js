const pageCode = {};

export { pageCode as default };
//# sourceMappingURL=page-code.js.map

// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// Worker
export const createWorker = /* @__PURE__ */ temporarilyNotSupport('createWorker')

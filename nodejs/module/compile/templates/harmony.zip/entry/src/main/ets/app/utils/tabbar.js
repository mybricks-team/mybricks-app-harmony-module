import _defineProperty from '../../node_modules/@babel/runtime/helpers/esm/defineProperty.js';
import { EventEmitter } from './event.js';

const isDefine = val => val !== void 0 && val !== null && val !== "";
class TabbarInstance {
  constructor() {
    _defineProperty(this, "list", []);
    _defineProperty(this, "eventEmitter", new EventEmitter());
    _defineProperty(this, "setTabBarBadge", _ref => {
      let {
        index,
        text
      } = _ref;
      return new Promise((resolve, reject) => {
        if (isDefine(index)) {
          this.list[index].active = true;
          this.list[index].activeText = text;
          console.log("change", this.list);
          this.eventEmitter.dispatch("change", this.list);
        }
      });
    });
    _defineProperty(this, "hideTabBarRedDot", _ref2 => {
      let {
        index
      } = _ref2;
      return new Promise((resolve, reject) => {
        if (isDefine(index)) {
          this.list[index].active = false;
          this.list[index].activeText = 0;
          this.eventEmitter.dispatch("change", this.list);
        }
      });
    });
    _defineProperty(this, "removeTabBarBadge", this.hideTabBarRedDot);
    _defineProperty(this, "initWithLength", len => {
      this.list = new Array(len).fill(t => null).map(() => ({
        active: false,
        activeText: ""
      }));
    });
  }
}
const tabbarIns = new TabbarInstance();

export { tabbarIns };
//# sourceMappingURL=tabbar.js.map

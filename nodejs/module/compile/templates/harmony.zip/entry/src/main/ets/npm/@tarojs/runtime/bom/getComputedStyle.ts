// @ts-nocheck
export function getComputedStyle (node: any) {
  // @ts-ignore
  return node._st
}

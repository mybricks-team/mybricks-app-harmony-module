import { useRef, useState, useCallback, useMemo, useEffect } from '../../../npm/react';
import { proxyToRaw, rawToProxy } from './global/index.js';
import { isObject } from '../utils.js';
import baseHandlers from './handles.js';
import { globalTaskEmitter } from './global/taskEmitter.js';
import { globalReactionStack } from './global/reactionStack.js';

function observer(baseComponent) {
  function observerComponent(props) {
    const ref = useRef(null);
    const [, setState] = useState([]);
    const update = useCallback(() => {
      setState([]);
    }, []);
    useMemo(() => {
      if (!ref.current) {
        ref.current = new Reaction(update);
      }
    }, []);
    useEffect(() => {
      return () => {
        ref.current?.destroy();
        ref.current = null;
      };
    }, []);
    let render;
    ref.current?.track(() => {
      render = baseComponent(props);
    });
    return render;
  }
  return observerComponent;
}
function observable(obj) {
  if (!isObject(obj)) {
    return {};
  }
  if (proxyToRaw.has(obj)) {
    return obj;
  }
  return rawToProxy.get(obj) || createObservable(obj);
}
function createObservable(obj) {
  const handlers = baseHandlers;
  const observable2 = new Proxy(obj, handlers);
  rawToProxy.set(obj, observable2);
  proxyToRaw.set(observable2, obj);
  globalTaskEmitter.addTask(obj);
  return observable2;
}
class Reaction {
  constructor(update) {
    this.update = update;
  }
  track(fn) {
    globalReactionStack.autoRun(this.update, fn);
  }
  destroy() {
    globalTaskEmitter.deleteReaction(this.update);
  }
}

export { Reaction, observable, observer };
//# sourceMappingURL=index.js.map

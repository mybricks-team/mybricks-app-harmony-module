// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 联系人
export const chooseContact = /* @__PURE__ */ temporarilyNotSupport('chooseContact')
export const addPhoneContact = /* @__PURE__ */ temporarilyNotSupport('addPhoneContact')

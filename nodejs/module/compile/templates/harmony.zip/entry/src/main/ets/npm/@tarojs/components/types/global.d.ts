// @ts-nocheck
declare module 'swiper/bundle' {
    import Swiper from '../../../swiper';
    export = Swiper
}
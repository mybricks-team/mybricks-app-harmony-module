// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 加密
export const getUserCryptoManager = /* @__PURE__ */ temporarilyNotSupport('getUserCryptoManager')

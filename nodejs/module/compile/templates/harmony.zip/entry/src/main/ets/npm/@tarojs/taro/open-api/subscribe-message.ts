// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 订阅消息
export const requestSubscribeMessage = /* @__PURE__ */ temporarilyNotSupport('requestSubscribeMessage')
// 订阅设备消息
export const requestSubscribeDeviceMessage = /* @__PURE__ */ temporarilyNotSupport('requestSubscribeDeviceMessage')

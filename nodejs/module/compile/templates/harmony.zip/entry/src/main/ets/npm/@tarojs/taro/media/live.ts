// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 实时音视频
export const createLivePusherContext = /* @__PURE__ */ temporarilyNotSupport('createLivePusherContext')
export const createLivePlayerContext = /* @__PURE__ */ temporarilyNotSupport('createLivePlayerContext')

// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 发票
export const chooseInvoiceTitle = /* @__PURE__ */ temporarilyNotSupport('chooseInvoiceTitle')
export const chooseInvoice = /* @__PURE__ */ temporarilyNotSupport('chooseInvoice')

// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// TCP 通信
export const createTCPSocket = /* @__PURE__ */ temporarilyNotSupport('createTCPSocket')

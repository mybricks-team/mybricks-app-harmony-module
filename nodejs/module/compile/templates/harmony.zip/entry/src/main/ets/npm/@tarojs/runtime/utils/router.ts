// @ts-nocheck
export {
  addLeadingSlash,
  getCurrentPage,
  getHomePage,
  hasBasename,
  stripBasename,
  stripSuffix,
  stripTrailing
} from '../dist/runtime.esm'

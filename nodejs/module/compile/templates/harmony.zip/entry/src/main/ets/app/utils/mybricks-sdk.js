import React__default from '../../npm/react';

const genMybricksSdk = dynamicComps => ({
  comRef: fn => fn,
  comDef: fn => fn,
  renderCom: function (Fn) {
    let props = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    return /* @__PURE__ */React__default.createElement(Fn, props?.props);
  },
  /** 仅小程序使用，因为不能使用eval */
  render: id => {
    return dynamicComps?.[id] ?? (() => `找不到ID为${id}的组件代码`);
  }
});

export { genMybricksSdk };
//# sourceMappingURL=mybricks-sdk.js.map

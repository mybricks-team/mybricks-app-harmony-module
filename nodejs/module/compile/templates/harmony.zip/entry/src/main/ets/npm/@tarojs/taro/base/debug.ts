// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

export const setEnableDebug = /* @__PURE__ */ temporarilyNotSupport('setEnableDebug')
export const getRealtimeLogManager = /* @__PURE__ */ temporarilyNotSupport('getRealtimeLogManager')
export const getLogManager = /* @__PURE__ */ temporarilyNotSupport('getLogManager')

// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 字体
export const loadFontFace = /* @__PURE__ */ temporarilyNotSupport('getMenuButtonBoundingClientRect')

// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 日历
export const addPhoneRepeatCalendar = temporarilyNotSupport('addPhoneRepeatCalendar')
export const addPhoneCalendar = temporarilyNotSupport('addPhoneCalendar')

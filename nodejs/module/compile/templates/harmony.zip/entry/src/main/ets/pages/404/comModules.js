const comInstance = {};

export { comInstance as default };
//# sourceMappingURL=comModules.js.map

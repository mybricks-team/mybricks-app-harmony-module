// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 设备（组）音视频通话
export const requestDeviceVoIP = /* @__PURE__ */ temporarilyNotSupport('requestDeviceVoIP')
export const getDeviceVoIPList = /* @__PURE__ */ temporarilyNotSupport('getDeviceVoIPList')

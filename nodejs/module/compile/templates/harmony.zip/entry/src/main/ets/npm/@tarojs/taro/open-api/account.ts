// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 帐号信息
export const getAccountInfoSync = /* @__PURE__ */ temporarilyNotSupport('getAccountInfoSync')

import { window, navigator, document } from './npm/@tarojs/runtime';
import DynamicExternals from './dynamic-externals/index.js';
import React__default from './npm/react';
import ReactDom from './npm/@tarojs/react';
import { getGlobalData } from './utils.js';

const appInstance = getGlobalData();
appInstance.externals = {
  ...(DynamicExternals ?? {})
};
if ("harmony" !== "harmony") {
  appInstance.externals["@tarojs/taro"] = require("./npm/@tarojs/taro");
  appInstance.externals["@tarojs/components"] = require("./npm/@tarojs/components");
}
if ("harmony" === "h5") {
  const {
    Taro,
    TaroComponents
  } = require("./taro.h5");
  appInstance.externals["@tarojs/taro"] = Taro;
  appInstance.externals["@tarojs/components"] = TaroComponents;
}
appInstance.externals["React"] = React__default;
appInstance.externals["ReactDom"] = ReactDom;
if ("harmony" === "h5") {
  Object.assign(window, appInstance.externals);
  const isInWeiXin = /(MicroMessenger)/i.test(navigator.userAgent);
  if (isInWeiXin) {
    console.warn("检测到处于微信环境，自动加载微信SDK");
    const script = document.createElement("script");
    script.src = "//res.wx.qq.com/open/js/jweixin-1.6.0.js";
    document.getElementsByTagName("head")[0].appendChild(script);
  }
}
console.log("global ===>", appInstance, appInstance.externals);
//# sourceMappingURL=registExternals.js.map

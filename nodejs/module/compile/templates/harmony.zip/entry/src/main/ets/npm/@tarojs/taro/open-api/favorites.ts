// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 收藏
export const addVideoToFavorites = /* @__PURE__ */ temporarilyNotSupport('addVideoToFavorites')
export const addFileToFavorites = /* @__PURE__ */ temporarilyNotSupport('addFileToFavorites')

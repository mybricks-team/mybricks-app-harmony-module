import React__default, { useState, useMemo, useCallback } from '../../npm/react';
import Main from './Main.js';
import { jsx, jsxs } from '../../npm/react/jsx-runtime';

function MultiScene(_ref) {
  let {
    json,
    options,
    _context,
    scenesContext
  } = _ref;
  const [count, setCount] = useState(0);
  const [popupIds, setPopupIds] = useState([]);
  const {
    mainPageJson
  } = useMemo(() => {
    return {
      mainPageJson: json.scenes.filter(t => t.type !== "popup" && t.type !== "module")?.[0]
    };
  }, []);
  const scenesMap = useMemo(() => {
    if (Array.isArray(json.scenes)) {
      json.scenes.forEach(scene => {
        scenesContext.scenesMap[scene.id].json = scene;
        scenesContext.scenesMap[scene.id].type = scene.slot?.showType || scene.type;
      });
    }
    return scenesContext.scenesMap;
  }, []);
  const getOptions = useCallback(id => {
    const scenes = scenesMap[id];
    const {
      env
    } = options;
    env.canvas.open = async (sceneId, params, openType) => {
      let scenes2 = scenesMap[sceneId];
      if (scenes2.type === "popup") {
        setPopupIds(popupIds2 => {
          return popupIds2.indexOf(sceneId) > -1 ? popupIds2 : [...popupIds2, sceneId];
        });
      } else {
        await env.canvas._open(sceneId, params, openType);
        return;
      }
    };
    env.getModuleJSON = moduleId => {
      return scenesContext?.scenesMap?.[moduleId]?.json;
    };
    env.scenesOperate = scenesContext.scenesOperate;
    env.renderModule = (json2, renderOpts) => {
      const opts = {
        ...renderOpts,
        env,
        comInstance: options.comInstance,
        scenesOperate: scenesContext.scenesOperate
      };
      return /* @__PURE__ */jsx(Main, {
        json: {
          ...json2
        },
        opts,
        _context
      }, json2.id);
    };
    const initSceneCommon = _refs => {
      scenes._refs = _refs;
      const todo = scenes.todo;
      const {
        inputs,
        outputs
      } = _refs;
      const disableAutoRun = scenes.disableAutoRun;
      scenes.json.outputs.forEach(output => {
        outputs(output.id, value => {
          if (output.id === "apply") {
            scenes.parentScope?.outputs[output.id](value);
          } else {
            if (scenes.type !== "module") {
              scenes.show = false;
              scenes.todo = [];
              scenes._refs = null;
              scenes.parentScope?.outputs[output.id](value);
              scenes.parentScope = null;
              if (scenes.type === "popup") {
                setPopupIds(popupIds2 => {
                  return popupIds2.filter(id2 => id2 !== scenes.json.id);
                });
              } else {
                setCount(count2 => count2 + 1);
              }
            } else {
              scenes.parentScope?.outputs[output.id](value);
            }
          }
        });
      });
      if (todo.length) {
        todo.forEach(_ref2 => {
          let {
            type,
            todo: todo2
          } = _ref2;
          if (type === "inputs") {
            Promise.resolve().then(() => {
              inputs[todo2.pinId](todo2.value, id);
            });
          } else if (type === "globalVar") {
            const {
              comId,
              value,
              bindings
            } = todo2;
            _notifyBindings(_refs, comId, bindings, value);
          }
        });
        scenes.todo = [];
      } else if (!disableAutoRun) {}
      if (disableAutoRun) {
        Promise.resolve().then(() => {
          _refs.run();
        });
      }
    };
    const ref = _refs => {
      initSceneCommon(_refs);
      if (scenes.type !== "popup" && scenes.type !== "module") {
        options.ref(_refs);
      }
    };
    return {
      ...options,
      env,
      get disableAutoRun() {
        return scenes.disableAutoRun;
      },
      ref,
      _env: {
        loadCSSLazy() {},
        currentScenes: {
          close() {
            scenes.show = false;
            scenes.todo = [];
            scenes._refs = null;
            if (scenes.type === "popup") {
              setPopupIds(popupIds2 => {
                return popupIds2.filter(id2 => id2 !== scenes.json.id);
              });
            } else {
              setCount(count2 => count2 + 1);
            }
          }
        }
      },
      scenesOperate: scenesContext.scenesOperate
    };
  }, []);
  const popups = useMemo(() => {
    if (popupIds.length) {
      return popupIds.map(sceneId => {
        const scene = scenesMap[sceneId];
        const json2 = scene.json;
        const {
          id
        } = json2;
        return /* @__PURE__ */jsx(Main, {
          json: {
            ...json2
          },
          opts: getOptions(id),
          style: {
            position: "absolute",
            top: 0,
            left: 0,
            zIndex: 99999,
            backgroundColor: "#ffffff00"
          },
          _context
        }, json2.id);
      });
    }
    return null;
  }, [popupIds]);
  return /* @__PURE__ */jsxs(React__default.Fragment, {
    children: [/* @__PURE__ */jsx(Main, {
      json: mainPageJson,
      opts: getOptions(mainPageJson.id),
      _context
    }, mainPageJson.id), popups]
  });
}
function _notifyBindings(_refs, comId, bindings, value) {
  const com = _refs.get(comId);
  if (com) {
    if (Array.isArray(bindings)) {
      bindings.forEach(binding => {
        let nowObj = com;
        const ary = binding.split(".");
        ary.forEach((nkey, idx) => {
          if (idx !== ary.length - 1) {
            nowObj = nowObj[nkey];
          } else {
            nowObj[nkey] = value;
          }
        });
      });
    }
  }
}

export { MultiScene as default };
//# sourceMappingURL=MultiScene.js.map

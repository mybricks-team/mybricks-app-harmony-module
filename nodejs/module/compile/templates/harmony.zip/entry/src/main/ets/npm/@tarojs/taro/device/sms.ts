// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 短信
export const sendSms = /* @__PURE__ */ temporarilyNotSupport('sendSms')

// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 设置
export const openSetting = /* @__PURE__ */ temporarilyNotSupport('openSetting')
export const getSetting = /* @__PURE__ */ temporarilyNotSupport('getSetting')

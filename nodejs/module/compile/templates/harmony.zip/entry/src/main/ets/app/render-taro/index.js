import Main from './Main.js';
import MultiScene from './MultiScene.js';
import executor from './executor.js';
import { observable } from './observable/index.js';
import { jsx } from '../../npm/react/jsx-runtime';
export { PageContext, ScenesContext } from './scenesContext.js';

function render(json) {
  let opts = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
  let _context = arguments.length > 2 ? arguments[2] : void 0;
  let scenesContext = arguments.length > 3 ? arguments[3] : void 0;
  if (!json.slot && !json.scenes) {
    executor({
      json,
      comInstance: opts.comInstance,
      getComDef: def => {
        return _context.getComDef(def);
      },
      events: opts.events,
      env: {
        ...opts.env
      },
      ref(_refs) {
        if (typeof opts.ref === "function") {
          opts.ref(_refs);
        }
      },
      onError: _context.onError,
      logger: _context.logger,
      scenesOperate: {
        ...(opts.scenesOperate ?? {}),
        open: _ref => {
          let {
            todo,
            frameId,
            parentScope
          } = _ref;
          opts.env.callServiceFx(frameId, todo.value).then(_ref2 => {
            let {
              id,
              value
            } = _ref2;
            parentScope.outputs[id](value);
          });
        },
        inputs: () => {}
      }
    }, {
      observable: observable
    });
    return;
  }
  if (Array.isArray(json.scenes)) {
    return /* @__PURE__ */jsx(MultiScene, {
      json,
      options: opts,
      _context,
      scenesContext
    });
  }
  return /* @__PURE__ */jsx(Main, {
    json,
    opts,
    _context
  });
}

export { render };
//# sourceMappingURL=index.js.map

// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 收货地址
export const chooseAddress = /* @__PURE__ */ temporarilyNotSupport('chooseAddress')

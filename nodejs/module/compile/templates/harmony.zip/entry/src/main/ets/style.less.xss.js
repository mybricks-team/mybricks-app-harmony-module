const style_less = '';

export { style_less as default };
//# sourceMappingURL=style.less.xss.js.map

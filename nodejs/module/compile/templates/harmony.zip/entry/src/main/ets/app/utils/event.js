import _defineProperty from '../../node_modules/@babel/runtime/helpers/esm/defineProperty.js';

class EventEmitter {
  constructor() {
    _defineProperty(this, "eventsCache", {});
    _defineProperty(this, "addEventListner", (evtName, listner) => {
      if (!this.eventsCache[evtName]) {
        this.eventsCache[evtName] = /* @__PURE__ */new Set([listner]);
        return;
      }
      this.eventsCache[evtName].add(listner);
    });
    _defineProperty(this, "removeEventListner", (evtName, listner) => {
      if (this.eventsCache[evtName]) {
        this.eventsCache[evtName].delete(listner);
      }
    });
    _defineProperty(this, "dispatch", (evtName, detail) => {
      if (!this.eventsCache[evtName]) {
        return;
      }
      let hasPreventDefault = false;
      (this.eventsCache[evtName] ?? []).forEach(listner => listner(detail));
      return hasPreventDefault;
    });
  }
}

export { EventEmitter };
//# sourceMappingURL=event.js.map

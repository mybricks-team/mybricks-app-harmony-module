// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 微信运动
export const shareToWeRun = /* @__PURE__ */ temporarilyNotSupport('shareToWeRun')
export const getWeRunData = /* @__PURE__ */ temporarilyNotSupport('getWeRunData')

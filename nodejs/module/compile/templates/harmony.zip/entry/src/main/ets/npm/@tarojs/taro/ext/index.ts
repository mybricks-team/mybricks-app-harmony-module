// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 第三方平台
export const getExtConfigSync = /* @__PURE__ */ temporarilyNotSupport('getExtConfigSync')
export const getExtConfig = /* @__PURE__ */ temporarilyNotSupport('getExtConfig')

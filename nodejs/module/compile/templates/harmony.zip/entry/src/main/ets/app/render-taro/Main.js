import { useMemo, useLayoutEffect } from '../../npm/react';
import executor from './executor.js';
import RenderSlot from './RenderSlot.js';
import ErrorBoundary from './ErrorBoundary/index.js';
import { observable } from './observable/index.js';
import { jsx } from '../../npm/react/jsx-runtime';

const regAry = (comAray, comDefs) => {
  comAray.forEach(comDef => {
    if (comDef.comAray) {
      regAry(comDef.comAray, comDefs);
    } else {
      comDefs[`${comDef.namespace}-${comDef.version}`] = comDef;
    }
  });
};
function Main(_ref) {
  let {
    json,
    opts,
    _context,
    style = {},
    root = true
  } = _ref;
  const comInstance = useMemo(() => {
    return opts.comInstance || {};
  }, []);
  const {
    env,
    onError,
    logger,
    slot,
    getComDef
  } = useMemo(() => {
    const slot2 = json.slot;
    if (slot2?.showType === "module") {
      const {
        style: slotStyle
      } = slot2;
      if (slotStyle.heightAuto) {
        style.height = "fit-content";
      } else if (slotStyle.heightFull) {
        style.height = "100%";
      } else {
        style.height = slotStyle.height;
      }
      if (slotStyle.widthAuto) {
        style.width = "fit-content";
      } else if (slotStyle.widthFull) {
        style.width = "100%";
      } else {
        style.width = slotStyle.width;
      }
      slot2.style.backgroundColor = slot2.style.backgroundColor || "#ffffff00";
    }
    if (json.type === "module") {
      slot2.style.backgroundColor = slot2.style.backgroundColor || "#ffffff00";
    }
    return {
      env: opts.env,
      onError: _context.onError,
      logger: _context.logger,
      getComDef: def => _context.getComDef(def),
      slot: json.slot
    };
  }, []);
  const [context, refs, activeTriggerInput] = useMemo(() => {
    try {
      let refs2;
      let activeTriggerInput2 = true;
      const context2 = executor({
        json,
        comInstance,
        getComDef,
        events: opts.events,
        env,
        ref(_refs) {
          refs2 = _refs;
          if (typeof opts.ref === "function") {
            opts.ref(_refs);
            activeTriggerInput2 = false;
          }
        },
        onError,
        logger,
        scenesOperate: opts.scenesOperate
      }, {
        //////TODO goon
        observable: opts.observable || observable
      });
      return [context2, refs2, activeTriggerInput2];
    } catch (ex) {
      console.error(ex);
      throw new Error(`导出的JSON.script执行异常.`);
    }
  }, []);
  useLayoutEffect(() => {
    if (!opts.disableAutoRun) {
      if (activeTriggerInput) {
        const {
          inputs
        } = refs;
        const jsonInputs = json.inputs;
        if (inputs && Array.isArray(jsonInputs)) {
          jsonInputs.forEach(input => {
            const {
              id,
              mockData
            } = input;
            let value = void 0;
            inputs[id](value);
          });
        }
      }
      refs.run();
    }
  }, []);
  return /* @__PURE__ */jsx(ErrorBoundary, {
    errorTip: `页面渲染错误`,
    children: /* @__PURE__ */jsx(RenderSlot, {
      env,
      _env: opts._env,
      slot,
      style,
      getComDef,
      context,
      __rxui_child__: !opts.observable,
      onError,
      logger,
      root,
      options: opts,
      ...(json.type === "module" ? {
        // 模块添加画布的点击事件
        onClick() {
          console.log("click", opts.outputs);
          opts.outputs?.["click"]();
        }
      } : {})
    })
  });
}

export { Main as default };
//# sourceMappingURL=Main.js.map

import _defineProperty from '../../../node_modules/@babel/runtime/helpers/esm/defineProperty.js';
import React__default from '../../../npm/react';
import { jsxs, jsx } from '../../../npm/react/jsx-runtime';

const css = {};
class ErrorBoundary extends React__default.PureComponent {
  constructor() {
    super(...arguments);
    _defineProperty(this, "state", {
      hasError: false,
      error: null,
      errorInfo: null
    });
  }
  static getDerivedStateFromError(error) {
    return {
      hasError: true,
      error: error?.stack || error?.message || error?.toString?.()
    };
  }
  componentDidCatch(error, errorInfo) {
    console.error(error, errorInfo);
    this.setState({
      error: error?.stack || error?.message || error?.toString?.(),
      errorInfo: errorInfo?.stack || errorInfo?.message || errorInfo?.toString?.()
    });
  }
  render() {
    const {
      hasError,
      error,
      errorInfo
    } = this.state;
    const {
      children,
      errorTip
    } = this.props;
    if (!hasError) {
      return children;
    }
    return /* @__PURE__ */jsxs("view", {
      className: css.error,
      children: [/* @__PURE__ */jsx("view", {
        children: errorTip || `渲染错误`
      }), /* @__PURE__ */jsx("view", {
        children: error || errorInfo
      })]
    });
  }
}

export { ErrorBoundary as default };
//# sourceMappingURL=index.js.map

// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// UDP 通信
export const createUDPSocket = /* @__PURE__ */ temporarilyNotSupport('createUDPSocket')

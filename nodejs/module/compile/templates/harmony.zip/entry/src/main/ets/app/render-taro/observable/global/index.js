export { globalTaskEmitter } from './taskEmitter.js';
export { globalReactionStack } from './reactionStack.js';

const proxyToRaw = /* @__PURE__ */new WeakMap();
const rawToProxy = /* @__PURE__ */new WeakMap();

export { proxyToRaw, rawToProxy };
//# sourceMappingURL=index.js.map

// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 微信红包
export const showRedPackage = /* @__PURE__ */ temporarilyNotSupport('showRedPackage')

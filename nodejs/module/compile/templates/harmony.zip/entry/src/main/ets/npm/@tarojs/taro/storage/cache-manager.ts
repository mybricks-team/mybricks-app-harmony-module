// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 周期性更新
export const createCacheManager = /* @__PURE__ */ temporarilyNotSupport('createCacheManager')

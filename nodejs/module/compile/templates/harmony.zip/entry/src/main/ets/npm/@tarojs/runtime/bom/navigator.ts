// @ts-nocheck
export { navigator } from '../dist/runtime.esm'

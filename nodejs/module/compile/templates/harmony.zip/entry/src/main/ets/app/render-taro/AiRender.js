import { createContext, isValidElement, cloneElement, Children, useContext, Component } from '../../npm/react';
import { jsx } from '../../npm/react/jsx-runtime';

const REACT_ELEMENT_TYPE = Symbol.for("react.element");
const REACT_PORTAL_TYPE = Symbol.for("react.portal");
const REACT_FRAGMENT_TYPE = Symbol.for("react.fragment");
const REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode");
const REACT_PROFILER_TYPE = Symbol.for("react.profiler");
const REACT_PROVIDER_TYPE = Symbol.for("react.provider");
const REACT_CONTEXT_TYPE = Symbol.for("react.context");
const REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref");
const REACT_SUSPENSE_TYPE = Symbol.for("react.suspense");
const REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list");
const REACT_MEMO_TYPE = Symbol.for("react.memo");
const REACT_LAZY_TYPE = Symbol.for("react.lazy");
const REACT_OFFSCREEN_TYPE = Symbol.for("react.offscreen");
const proKey = "harmony" === "h5" ? "data-key" : "_key";
const Context = /* @__PURE__ */createContext({
  _key: null,
  _data: null
});
const Provider = Context.Provider;
const Next = _ref => {
  let {
    children
  } = _ref;
  if (/* @__PURE__ */isValidElement(children)) {
    const {
      type
    } = children;
    const typeString = Object.prototype.toString.call(type);
    switch (typeString) {
      case "[object String]":
        return /* @__PURE__ */jsx(StringNext, {
          children
        });
      case "[object Object]":
        return /* @__PURE__ */jsx(ObjectNext, {
          children
        });
      case "[object Function]":
        return /* @__PURE__ */jsx(FunctionNext, {
          children
        });
      case "[object Symbol]":
        return /* @__PURE__ */jsx(SymbolNext, {
          children
        });
      default:
        return children;
    }
  }
  return children;
};
const ProxyNext = _ref2 => {
  let {
    children,
    mergeProps
  } = _ref2;
  const oriProps = {
    ...children.props
  };
  Object.entries(mergeProps).forEach(_ref3 => {
    let [key, value] = _ref3;
    if (!(key in oriProps)) {
      oriProps[key] = value;
    } else {
      const valueType = Object.prototype.toString.call(value);
      if (valueType === "[object Array]") {
        const oriValue = oriProps[key];
        value.forEach((item, index) => {
          if (item) {
            oriValue[index] = item;
          }
        });
        oriProps[key] = [...oriValue];
      } else if (valueType === "[object Object]") {
        oriProps[key] = {
          ...oriProps[key],
          ...value
        };
      } else {
        oriProps[key] = value;
      }
    }
  });
  return /* @__PURE__ */jsx(Next, {
    children: /* @__PURE__ */cloneElement(children, oriProps)
  });
};
const Render = _ref4 => {
  let {
    _data,
    children
  } = _ref4;
  if (_data) {
    return /* @__PURE__ */jsx(Provider, {
      value: {
        _data
      },
      children: /* @__PURE__ */jsx(Render, {
        children
      })
    });
  }
  if (Array.isArray(children)) {
    return Children.map(children, child => {
      return /* @__PURE__ */jsx(Render, {
        children: child
      });
    });
  }
  if (/* @__PURE__ */isValidElement(children)) {
    const {
      props
    } = children;
    const _key = props[proKey];
    if (_key) {
      const {
        _key: _contextKey,
        _data: _data2
      } = useContext(Context);
      if (_key !== _contextKey) {
        const mergeProps = _data2?.[_key];
        return /* @__PURE__ */jsx(Provider, {
          value: {
            _key,
            _data: _data2
          },
          children: mergeProps ? /* @__PURE__ */jsx(ProxyNext, {
            mergeProps,
            children
          }) : /* @__PURE__ */jsx(Next, {
            children
          })
        });
      } else {
        return /* @__PURE__ */jsx(Next, {
          children: /* @__PURE__ */cloneElement(children, {
            [proKey]: null
          })
        });
      }
    }
    return /* @__PURE__ */jsx(Next, {
      children
    });
  }
  return children;
};
const renderFunctionHijack = _ref5 => {
  let {
    type,
    render,
    next
  } = _ref5;
  if (type.__airender__) {
    type.__airender__ = null;
    const oriRender = type.__ori__;
    next(oriRender);
    type.__runairender__ = true;
  } else if (!type.__runairender__) {
    const oriRender = render;
    next(oriRender);
    type.__runairender__ = true;
  }
};
const StringNext = _ref6 => {
  let {
    children
  } = _ref6;
  const {
    _key,
    _data
  } = useContext(Context);
  const {
    props
  } = children;
  const {
    children: nextChildren
  } = props;
  if (_key) {
    return /* @__PURE__ */cloneElement(children, {
      [proKey]: _key,
      children: nextChildren ? /* @__PURE__ */jsx(Provider, {
        value: {
          _key: null,
          _data
        },
        children: /* @__PURE__ */jsx(Render, {
          children: nextChildren
        })
      }) : null
    });
  }
  return /* @__PURE__ */cloneElement(children, {
    children: nextChildren ? /* @__PURE__ */jsx(Render, {
      children: nextChildren
    }) : null
  });
};
const ObjectNext = _ref7 => {
  let {
    children
  } = _ref7;
  const {
    type
  } = children;
  switch (type["$$typeof"]) {
    case REACT_FORWARD_REF_TYPE:
      return /* @__PURE__ */jsx(ForwardRefNext, {
        children
      });
    case REACT_PROVIDER_TYPE:
      return /* @__PURE__ */jsx(ProviderNext, {
        children
      });
    case REACT_MEMO_TYPE:
      return /* @__PURE__ */jsx(MemoNext, {
        children
      });
    default:
      return children;
  }
};
const ForwardRefNext = _ref8 => {
  let {
    children
  } = _ref8;
  const {
    props,
    ref,
    type
  } = children;
  const nextChildren = props.children;
  if (nextChildren) {
    if (typeof nextChildren === "function") {
      const oriNextChildren = nextChildren;
      return /* @__PURE__ */cloneElement(children, {
        children: function () {
          return /* @__PURE__ */jsx(Render, {
            children: oriNextChildren(...arguments)
          });
        }
      });
    }
  }
  if (type.__airender__ || !type.__runairender__) {
    renderFunctionHijack({
      type,
      render: type.render,
      next: oriRender => {
        type.render = function () {
          const res = oriRender(...arguments);
          return /* @__PURE__ */jsx(Render, {
            children: res
          });
        };
      }
    });
  }
  return children;
};
const ProviderNext = _ref9 => {
  let {
    children
  } = _ref9;
  const {
    props
  } = children;
  const {
    children: nextChildren
  } = props;
  if (nextChildren) {
    return /* @__PURE__ */cloneElement(children, {
      children: /* @__PURE__ */jsx(Render, {
        children: nextChildren
      })
    });
  }
  return children;
};
const MemoNext = _ref10 => {
  let {
    children
  } = _ref10;
  const {
    type,
    props
  } = children;
  if (typeof type.type === "function") {
    const next = type.type(props);
    return /* @__PURE__ */jsx(Render, {
      children: next
    });
  }
  if (type.type["$$typeof"] === REACT_FORWARD_REF_TYPE) {
    const next = type.type.render(props, children.ref);
    return /* @__PURE__ */jsx(Render, {
      children: next
    });
  } else {}
  return children;
};
const FunctionNext = _ref11 => {
  let {
    children
  } = _ref11;
  const {
    type,
    props
  } = children;
  if (type.prototype instanceof Component) {
    if (type.__airender__ || !type.__runairender__) {
      renderFunctionHijack({
        type,
        render: type.prototype.render,
        next: oriRender => {
          type.prototype.render = function () {
            const res = oriRender.call(this);
            return /* @__PURE__ */jsx(Render, {
              children: res
            });
          };
        }
      });
    }
    return children;
  }
  return /* @__PURE__ */jsx(Render, {
    children: type(props)
  });
};
const ClassNext = Component2 => {
  return class WrapComponent extends Component2 {
    constructor(props) {
      super(props);
    }
    render() {
      const children = super.render();
      if (!children) {
        return children;
      }
      if (Array.isArray(children)) {
        return /* @__PURE__ */jsx(Render, {
          children
        });
      }
      const {
        props
      } = children;
      const {
        children: nextChildren
      } = props;
      if (nextChildren) {
        return /* @__PURE__ */cloneElement(children, {
          children: /* @__PURE__ */jsx(Render, {
            children: nextChildren
          })
        });
      }
      return children;
    }
  };
};
const SymbolNext = _ref12 => {
  let {
    children
  } = _ref12;
  const {
    props
  } = children;
  const {
    children: nextChildren
  } = props;
  if (nextChildren) {
    return /* @__PURE__ */cloneElement(children, {
      children: /* @__PURE__ */jsx(Render, {
        children: nextChildren
      })
    });
  }
  return children;
};

export { Render as default };
//# sourceMappingURL=AiRender.js.map

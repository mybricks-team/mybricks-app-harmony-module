import _defineProperty from '../../../../node_modules/@babel/runtime/helpers/esm/defineProperty.js';
import { isObject } from '../../utils.js';
import { proxyToRaw, rawToProxy } from './index.js';

class TaskEmitter {
  constructor() {
    _defineProperty(this, "taskMap", /* @__PURE__ */new WeakMap());
    _defineProperty(this, "reactionToTaskMap", /* @__PURE__ */new WeakMap());
  }
  addTask(obj) {
    this.taskMap.set(obj, /* @__PURE__ */new Map());
  }
  deleteTask(obj) {
    if (!isObject(obj)) {
      return;
    }
    const target = proxyToRaw.get(obj);
    proxyToRaw.delete(obj);
    rawToProxy.delete(target);
    const task = this.taskMap.get(target);
    this.taskMap.delete(target);
    for (let key of task.keys()) {
      this.deleteTask(rawToProxy.get(target[key]));
      const reactions = task.get(key);
      reactions?.forEach?.(reaction => {
        this.deleteReaction(reaction);
      });
    }
  }
  deleteReaction(reaction) {
    let reactionToTask = this.reactionToTaskMap.get(reaction);
    if (!reactionToTask) {
      return;
    }
    this.reactionToTaskMap.delete(reaction);
    reactionToTask.forEach(task => {
      task.forEach(value => {
        value.delete(reaction);
      });
    });
  }
  registReaction(reaction, _ref) {
    let {
      target,
      key
    } = _ref;
    const task = this.taskMap.get(target);
    if (task) {
      let reactions = task.get(key);
      if (!reactions) {
        reactions = /* @__PURE__ */new Set();
        task.set(key, reactions);
      }
      if (!reactions.has(reaction)) {
        reactions.add(reaction);
      }
      let reactionToTask = this.reactionToTaskMap.get(reaction);
      if (!reactionToTask) {
        reactionToTask = /* @__PURE__ */new Set();
        this.reactionToTaskMap.set(reaction, reactionToTask);
      }
      if (!reactionToTask.has(task)) {
        reactionToTask.add(task);
      }
    }
  }
  getReactions(_ref2) {
    let {
      target,
      key
    } = _ref2;
    const task = this.taskMap.get(target);
    if (!task) {
      return [];
    }
    const reactions = task.get(key) || [];
    return reactions;
  }
  runTask(operation) {
    const reactions = this.getReactions(operation);
    if (reactions.size) {
      reactions.forEach(run);
    }
  }
}
function run(fn) {
  fn();
}
const globalTaskEmitter = new TaskEmitter();

export { globalTaskEmitter };
//# sourceMappingURL=taskEmitter.js.map
